package com.nnn.app.DaoImpl;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.nnn.app.dao.MemberLoginDao;
import com.nnn.app.vo.MemberVo;

@Repository
public class MemberLoginDAOImpl implements MemberLoginDao {

	@Inject
	SqlSession session;
	
	@Override
	public String logincheck(MemberVo vo) throws Exception {
		return session.selectOne("member.logincheck", vo);
	}

}
