package com.nnn.app.DaoImpl;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.nnn.app.dao.MemberDetailDao;
import com.nnn.app.vo.MemberVo;

@Repository
public class MemberDetailDAOImpl implements MemberDetailDao {

	@Inject
	SqlSession session;
	
	@Override
	public MemberVo MemberDetail(Integer midx) throws Exception {
		return session.selectOne("member.detail", midx);
	}

}
