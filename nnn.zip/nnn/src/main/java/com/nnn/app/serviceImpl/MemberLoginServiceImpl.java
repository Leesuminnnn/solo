package com.nnn.app.serviceImpl;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.nnn.app.dao.MemberLoginDao;
import com.nnn.app.service.MemberLoginService;
import com.nnn.app.vo.MemberVo;

@Service
public class MemberLoginServiceImpl implements MemberLoginService {

	@Inject
	MemberLoginDao dao;

	@Override
	public String logincheck(MemberVo vo, HttpSession session) throws Exception {
		
		String status = dao.logincheck(vo);
		
		System.out.println(status+"------------");
		if (status == null) {
			System.out.println("statust = null");
			return null;
		} else {
			
			// 로그인에 성공하면 세션에 객체를 담는다
			System.out.println("###########service###############");
			System.out.println("status :" + status);
			System.out.println("midx : "+vo.getMidx());
			System.out.println("m_id : "+vo.getM_id());
			System.out.println("m_pw :"+vo.getM_pw());
			System.out.println("##########################");
			
			session.setAttribute("status", status);
			session.setAttribute("midx", vo.getMidx());
			session.setAttribute("m_id", vo.getM_id());
			session.setAttribute("m_pw", vo.getM_pw());
		}
		return status;
	}

}
