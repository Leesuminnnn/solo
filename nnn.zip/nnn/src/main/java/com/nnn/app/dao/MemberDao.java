package com.nnn.app.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nnn.app.vo.MemberVo;

@Repository
public class MemberDao {

	private SqlSession sqlSession;

	public static final String MAPPER = "member";

	@Autowired
	public MemberDao(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	// 회원 정보
	public MemberVo detail(int midx) {
		return sqlSession.selectOne(MAPPER+".detail", midx);
	}

	// 로그인 예시
	public MemberVo login(MemberVo memberVo) {
		return sqlSession.selectOne(MAPPER+".login", memberVo);
	}

	public List<MemberVo> Memberlist(MemberVo memberVo) {
		return sqlSession.selectList(MAPPER+".mlist", memberVo);
	}

	public int change(String m_id) {
		return sqlSession.update(MAPPER+".change",m_id);
	}

}
