package com.nnn.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nnn.app.dao.MemberDao;
import com.nnn.app.vo.MemberVo;

@Service
public class MemberService {

	private MemberDao memberDao;

	@Autowired
	public MemberService(MemberDao memberDao) {
		this.memberDao = memberDao;
	}

	// 회원정보 보기
	public MemberVo detail(Integer midx) {
		return memberDao.detail(midx);
	}

	// 로그인 예시
	public MemberVo login(MemberVo memberVo) {
		return memberDao.login(memberVo);
	}

	public List<MemberVo> Memberlist(MemberVo memberVo) {

		return memberDao.Memberlist(memberVo);
	}

	public int change(String m_id) {
		int result = 0;
		result = memberDao.change(m_id);
		return result;
	}
}
