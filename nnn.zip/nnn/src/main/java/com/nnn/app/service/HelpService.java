package com.nnn.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nnn.app.dao.HelpDao;
import com.nnn.app.vo.HelpVo;

@Service
public class HelpService {

	private HelpDao helpDao;
	
	@Autowired
	public HelpService(HelpDao helpDao) {
		this.helpDao = helpDao;
	}
	
	//리스트 보기
	public List<HelpVo> list(){
		return helpDao.list();
	}
	
	//글쓰기
	public int addHelp(HelpVo helpVo) {
		int result = 0;	//글쓰기 실패
		
		result = helpDao.addHelp(helpVo);
		
		return result;
	}
	
}
