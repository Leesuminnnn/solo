package com.nnn.app.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nnn.app.vo.HelpVo;

@Repository
public class HelpDao {
	
	private SqlSession sqlSession;
	
	public static final String MAPPER = "help";
	
	@Autowired
	public HelpDao(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public List<HelpVo> list(){
		return sqlSession.selectList(MAPPER+".list");
	}
	
	public int addHelp(HelpVo helpVo) {
		return sqlSession.insert(MAPPER+".addHelp", helpVo);
	}
}
