package com.nnn.app.serviceImpl;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.nnn.app.dao.MemberDetailDao;
import com.nnn.app.service.MemberDetailService;
import com.nnn.app.vo.MemberVo;

@Service
public class MemberDetailServiceImpl implements MemberDetailService {

	@Inject
	MemberDetailDao dao;

	
	@Override
	public MemberVo memberDetail(Integer midx) throws Exception {

		return dao.MemberDetail(midx);
	}

}
