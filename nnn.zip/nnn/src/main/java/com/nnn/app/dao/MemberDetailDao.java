package com.nnn.app.dao;

import com.nnn.app.vo.MemberVo;

public interface MemberDetailDao {

	public MemberVo MemberDetail(Integer midx)throws Exception;
	
	
}
