package com.nnn.app.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.nnn.app.service.MemberService;
import com.nnn.app.vo.MemberVo;

@Controller
@RequestMapping(value = "m/*")
public class MemberController {
	
//	MemberLoginService memberLoginService;
//	MemberDetailService memberDetailService;
	MemberService memberService;
	
	@Autowired
	public MemberController(MemberService memberService) {
		this.memberService = memberService;
	}
	
	@RequestMapping(value = "Login.do")
	public String login(Model model, HttpSession session) {
		// 로그인 요청 주소(get)
//		String kakaoUrl = "https://kauth.kakao.com/oauth/authorize?" + "client_id" + id + "&redirect_uri" + url
//				+ "response_type=code";
//		model.addAttribute("kakaUrl", kakaoUrl);

		System.out.println("Login 페이지");
		return "m/Login";
	}

	@RequestMapping(value = "Login_check.do", method = RequestMethod.POST)
	public String login_check(MemberVo vo, HttpSession session, Model model, HttpServletRequest request) throws Exception {
	    MemberVo loginMember = memberService.login(vo);

	    if (loginMember == null) {
	        model.addAttribute("msg", "아이디 또는 비밀번호를 확인해주세요.");
	        return "m/Login";
	    }else if(loginMember.getM_status().equals("2")){
	    	session.setAttribute("loginMember", loginMember);
	    	System.out.println("loginMember : " + loginMember);
	    	List<MemberVo> mlist = new ArrayList<MemberVo>();
			
			mlist = memberService.Memberlist(vo);
			model.addAttribute("mlist", mlist);
			System.out.println("mlist 값 : "+mlist);
	    	return "m/Admin";
	    }

	    // 로그인이 완료되면 이전 페이지로 이동하기	-- 정상 작동 되지 않음 해결해야함!!
	    String referer = request.getHeader("referer"); // referer 정보 가져오기
	    session.setAttribute("loginMember", loginMember);
	    System.out.println("loginMember : " + loginMember);
	    if (referer != null && !referer.contains("m/Login")) { // 이전 페이지가 null이 아니고 로그인 페이지가 아닌 경우
	        return "redirect:" + referer; // 이전 페이지로 이동
	    } else {
	        return "redirect:/"; // 메인 페이지로 이동
	    }
	}
	@ResponseBody
	@RequestMapping(value = "status.do", method = RequestMethod.POST)
	public String change(@RequestParam("m_status") String m_status, @RequestParam("m_id") String m_id) throws Exception {
		System.out.println("################################");
		System.out.println("m_id: "+m_id);
		
		String result ="N";	//이미 변경되어있을때
		int flag = memberService.change(m_id);
		
		if(flag == 1) result = "Y";
		
		return result;
		
	}
		
		
		
//		String status = memberLoginService.logincheck(vo, session);
//		// 로그인 실패
//		if (status == null) {
//			System.out.println("로그인 실패");
//			mav.setViewName("m/Login");
//			mav.addObject("msg", "error");
//			// 사용자인 경우
//		} else {
//			mav.setViewName("h/Main");
//			mav.addObject(status, "status");
//			System.out.println("################controller################");
//			System.out.println("status: " + status);
//			System.out.println("id: " + vo.getM_id());
//			System.out.println("################################");
//			// 관리자인 경우
//		return mav;
//		}
		
//		String name = memberService.login(vo);
//		
//		if(name != null) {
//			session.setAttribute("m_id", vo.getM_id());
//			System.out.println("m_id= "+vo.getM_id());
//			session.setAttribute("name", name);
//			System.out.println("name= "+ name );
//			mav.setViewName("redirect:/");
//		
//		}else {
//			mav.setViewName("member/Login");
//		}
//		
//		
//		return mav;
		
		
	

	// 회원 정보보기
	@RequestMapping(value = "Detail.do/{midx}")
	public String detail(@PathVariable("midx") Integer midx, Model model) throws Exception {

		model.addAttribute("detail", memberService.detail(midx));

		return "m/Detail";

	}

	@RequestMapping("Logout.do")

	public ModelAndView logout(HttpSession session, ModelAndView mav) {

		session.invalidate();
		mav.setViewName("home");
		mav.addObject("message", "logout");
		return mav;

	}
	@RequestMapping(value = "Admin.do")
	public ModelAndView admin(MemberVo vo, HttpSession session, ModelAndView mav) {
		
		System.out.println("관리자 페이지");
		
		List<MemberVo> mlist = new ArrayList<MemberVo>();
		
		mlist = memberService.Memberlist(vo);
		mav.addObject("mlist", mlist);
		System.out.println("mlist 값 : "+mlist);
		mav.setViewName("m/Admin");
		
		return mav;
	}
//	// kakao에서 발급받은 클라이언트 키
//	private final static String id = "ecfda70a16078a6b5a64478901f3dfb3";
//	// kakao에서 설정한 redirecturi
//	private final static String url = "http://localhost:8090/app/m/kakao/callback";
//
//	// 카카오로그인 REST API
//
//	public static JsonNode getAccessToken(String autorize_code) {
//
//		final String RequestUrl = "https://kauth.kakao.com/oauth/token";
//		final List<BasicNameValuePair> postParams = new ArrayList<BasicNameValuePair>();
//		postParams.add(new BasicNameValuePair("grant_type", "authorization_code"));
//		postParams.add(new BasicNameValuePair("client_id", id)); // REST API KEY
//		postParams.add(new BasicNameValuePair("redirect_uri", url)); // 리다이렉트 URI
//		postParams.add(new BasicNameValuePair("code", autorize_code)); // 로그인 과정중 얻은 code 값
//		final HttpClient client = HttpClientBuilder.create().build();
//		final HttpPost post = new HttpPost(RequestUrl);
//		JsonNode returnNode = null;
//		try {
//			post.setEntity(new UrlEncodedFormEntity(postParams));
//			final HttpResponse response = client.execute(post);
//			final int responseCode = response.getStatusLine().getStatusCode();
//			System.out.println("\nSending 'POST' request to URL : " + RequestUrl);
//			System.out.println("Post parameters : " + postParams);
//			System.out.println("Response Code : " + responseCode);
//
//			// JSON 형태 반환값 처리
//			ObjectMapper mapper = new ObjectMapper();
//			returnNode = mapper.readTree(response.getEntity().getContent());
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		} catch (ClientProtocolException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//		}
//		return returnNode;
//	}
//
//	// 기존의 코드
//	public static JsonNode getKakaoUserInfo(String access_token) {
//		final String RequestUrl = "https://kapi.kakao.com/v2/user/me";
//		final HttpClient client = HttpClientBuilder.create().build();
//		final HttpPost post = new HttpPost(RequestUrl);
//		String accessToken = access_token;
//
//		// add header
//		post.addHeader("Authorization", "Bearer " + accessToken);
//		JsonNode returnNode = null;
//		try {
//			final HttpResponse response = client.execute(post);
//			final int responseCode = response.getStatusLine().getStatusCode();
//			System.out.println("\nSending 'POST' request to URL : " + RequestUrl);
//			System.out.println("Response Code : " + responseCode);
//
//			// JSON 형태 반환값 처리
//			ObjectMapper mapper = new ObjectMapper();
//			returnNode = mapper.readTree(response.getEntity().getContent());
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//		} catch (ClientProtocolException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//			// clear resources
//		}
//		return returnNode;
//
//	}
//
//	@RequestMapping(value = "/kakao/callback", method = RequestMethod.GET)
//	public String kakaologin(@RequestParam("code") String code, HttpSession session) throws Exception {
//		JsonNode jsonToken = getAccessToken(code);
//		String access_token = jsonToken.get("access_token").toString();
//		JsonNode userInfo = getKakaoUserInfo(access_token);
//		String id = userInfo.get("id").toString();
//		String nickName = userInfo.get("properties").get("nickname").toString();
//		session.setAttribute("userid", nickName);
//		System.out.println("id" + id + "nickName" + nickName);
//		return "redirect:/h/Main.do";
//	}


}
