package com.nnn.app.vo;

import java.util.Date;

import lombok.Data;

@Data
public class HelpVo {
/*
CREATE TABLE testdb.HELP(
hidx INT AUTO_INCREMENT not NULL PRIMARY KEY,
h_regdate DATETIME DEFAULT NOW(),
h_delyn CHAR(1) DEFAULT 'N',
h_userId VARCHAR(20) NOT NULL,
h_userName VARCHAR(20) NOT NULL,
h_startTime DATETIME DEFAULT NOW(),
h_endTime DATETIME DEFAULT NOW(),
h_name VARCHAR(20),
h_no VARCHAR(20),
h_number VARCHAR(20),
h_img VARCHAR(100),
h_imgName VARCHAR(100)
);
*/

	private int hidx;
	private Date h_regdate;
	private String h_delyn;
	private String h_userId;
	private String h_userName;
	private String h_startTime;
	private String h_endTime;
	private String h_name;
	private String h_no;
	private String h_number;
	private String h_img;
	private String h_imgName;
	
	
	
	
	
	
}
