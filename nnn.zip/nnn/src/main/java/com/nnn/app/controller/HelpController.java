package com.nnn.app.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nnn.app.service.HelpService;
import com.nnn.app.vo.HelpVo;


@RequestMapping(value="h/*")
@Controller
public class HelpController {

	private HelpService helpService;
	
	@Autowired
	public HelpController(HelpService helpService) {
		this.helpService = helpService;
	}
	
	@RequestMapping(value="Main.do", method = RequestMethod.GET)
	public ModelAndView main(ModelAndView mav, HttpSession session) throws Exception {
		System.out.println("-----------------1");
		
		
		System.out.println("--------------Main접속");
		
		mav.setViewName("h/Main");
		
		return mav;
	}
	
	@RequestMapping(value="List.do", method = RequestMethod.GET)
	public ModelAndView list(ModelAndView mav, HttpSession session) throws Exception {
		System.out.println("-----------------1");
		
		List<HelpVo> list = helpService.list();
		
		System.out.println("--------------List접속");
		
		mav.addObject("list", list);
		
		mav.setViewName("h/List");
		
		return mav;
	}
	
	@RequestMapping(value="Insert.do", method = RequestMethod.GET)
	public String insert(Model model, HttpSession session) throws Exception {
		System.out.println("--------------insert접속");
		
		
		return "h/Insert";
	}
	
	@RequestMapping(value = "InsertProcess.do")
	public String addHelp(HelpVo helpVo) {
		// 요청매핑이 있는 메소드의 매개변수에 Vo나 자바클래스가 있는 경우 전달된 값을 그 객체에 매핑시켜줌
		// 이러한 객체를 커맨드 객체라고 함.
		int result = helpService.addHelp(helpVo);

		String viewPage = null;

		if (result == 1) {
			viewPage = "redirect:List.do";
		} else {
			viewPage = "h/Insert";
		}

		return viewPage;
	}
	
	
	
	
	
	
	
}
