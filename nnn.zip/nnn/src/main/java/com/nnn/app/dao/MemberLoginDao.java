package com.nnn.app.dao;

import com.nnn.app.vo.MemberVo;

public interface MemberLoginDao {

	public String logincheck(MemberVo vo)throws Exception;
	
	
}
